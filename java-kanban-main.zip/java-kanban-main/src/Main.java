import tasks.Epic;
import tasks.Subtask;
import tasks.Task;
import manager.Manager;

public class Main {

    public static void main(String[] args) {
        Manager manager = new Manager();

        manager.addTask(new Task("Задача 1", "Описание 1"));
        manager.addTask(new Task("Задача 2", "Описание 2"));

        Epic epic1 = new Epic("Задача эпика 1", "Описание эпика 1");
        manager.addEpic(epic1);
        manager.addSubtask(new Subtask("Подзадача 1","Описание подзадачи 1"), epic1);
        manager.addSubtask(new Subtask("Подзадача 2","Описание подзадачи 2"), epic1);

        Epic epic2 = new Epic("Задача эпика 2", "Описание эпика 2");
        manager.addEpic(epic2);
        manager.addSubtask(new Subtask("Подзадача 1","Описание подзадачи 1"), epic2);


    }
}




